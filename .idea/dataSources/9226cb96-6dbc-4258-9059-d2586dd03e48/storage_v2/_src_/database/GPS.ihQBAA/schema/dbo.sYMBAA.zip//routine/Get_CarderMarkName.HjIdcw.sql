CREATE FUNCTION [dbo].[Get_CarderMarkName] (
	@ID  nvarchar(10)
	)
RETURNS nvarchar(max) AS
begin
declare
@CarderMarkName nvarchar(10),
@c int
		begin
			Select @c = count(ID) FROM Carder where [ID] = @ID
			if(@c=0)
				begin
					Select @CarderMarkName = '*未录入'
				end
			else
				begin
					Select @CarderMarkName = Carder_MarkName FROM Carder  where [ID] = @ID
				end
		end
	return @CarderMarkName
end
go

